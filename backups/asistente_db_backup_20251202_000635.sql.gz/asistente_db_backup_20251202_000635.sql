--
-- PostgreSQL database dump
--

-- Dumped from database version 15.5
-- Dumped by pg_dump version 15.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: Categoria; Type: TYPE; Schema: public; Owner: asistente
--

CREATE TYPE public."Categoria" AS ENUM (
    'TRABAJO',
    'PERSONAL',
    'SOCIAL',
    'OTRO'
);


ALTER TYPE public."Categoria" OWNER TO asistente;

--
-- Name: Prioridad; Type: TYPE; Schema: public; Owner: asistente
--

CREATE TYPE public."Prioridad" AS ENUM (
    'BAJA',
    'MEDIA',
    'ALTA',
    'URGENTE'
);


ALTER TYPE public."Prioridad" OWNER TO asistente;

--
-- Name: TipoEnergia; Type: TYPE; Schema: public; Owner: asistente
--

CREATE TYPE public."TipoEnergia" AS ENUM (
    'relax',
    'baja',
    'media',
    'alta',
    'pico'
);


ALTER TYPE public."TipoEnergia" OWNER TO asistente;

--
-- Name: TipoEnfoque; Type: TYPE; Schema: public; Owner: asistente
--

CREATE TYPE public."TipoEnfoque" AS ENUM (
    'velocidad',
    'perfeccion',
    'balanceado'
);


ALTER TYPE public."TipoEnfoque" OWNER TO asistente;

--
-- Name: TipoEstadoProyecto; Type: TYPE; Schema: public; Owner: asistente
--

CREATE TYPE public."TipoEstadoProyecto" AS ENUM (
    'idea',
    'planificacion',
    'en_curso',
    'pausado',
    'completado',
    'cancelado',
    'archivado'
);


ALTER TYPE public."TipoEstadoProyecto" OWNER TO asistente;

--
-- Name: TipoEstadoTarea; Type: TYPE; Schema: public; Owner: asistente
--

CREATE TYPE public."TipoEstadoTarea" AS ENUM (
    'por_hacer',
    'en_progreso',
    'bloqueada',
    'en_revision',
    'completada',
    'cancelada'
);


ALTER TYPE public."TipoEstadoTarea" OWNER TO asistente;

--
-- Name: TipoLibertad; Type: TYPE; Schema: public; Owner: asistente
--

CREATE TYPE public."TipoLibertad" AS ENUM (
    'receta',
    'resultado',
    'mixto'
);


ALTER TYPE public."TipoLibertad" OWNER TO asistente;

--
-- Name: TipoMoscow; Type: TYPE; Schema: public; Owner: asistente
--

CREATE TYPE public."TipoMoscow" AS ENUM (
    'must',
    'should',
    'could',
    'wont'
);


ALTER TYPE public."TipoMoscow" OWNER TO asistente;

--
-- Name: TipoRiesgo; Type: TYPE; Schema: public; Owner: asistente
--

CREATE TYPE public."TipoRiesgo" AS ENUM (
    'bajo',
    'medio',
    'alto',
    'critico'
);


ALTER TYPE public."TipoRiesgo" OWNER TO asistente;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: asistente
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO asistente;

--
-- Name: areas_vida; Type: TABLE; Schema: public; Owner: asistente
--

CREATE TABLE public.areas_vida (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    descripcion text,
    color_hex character varying(7),
    orden_visualizacion integer,
    activa boolean
);


ALTER TABLE public.areas_vida OWNER TO asistente;

--
-- Name: TABLE areas_vida; Type: COMMENT; Schema: public; Owner: asistente
--

COMMENT ON TABLE public.areas_vida IS 'Campos de vida donde Guillermo desarrolla proyectos';


--
-- Name: areas_vida_id_seq; Type: SEQUENCE; Schema: public; Owner: asistente
--

CREATE SEQUENCE public.areas_vida_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.areas_vida_id_seq OWNER TO asistente;

--
-- Name: areas_vida_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: asistente
--

ALTER SEQUENCE public.areas_vida_id_seq OWNED BY public.areas_vida.id;


--
-- Name: compromisos; Type: TABLE; Schema: public; Owner: asistente
--

CREATE TABLE public.compromisos (
    id integer NOT NULL,
    titulo text NOT NULL,
    descripcion text,
    "personaNombre" text NOT NULL,
    "fechaLimite" timestamp(3) without time zone,
    "yoMeComprometi" boolean DEFAULT false NOT NULL,
    cumplido boolean DEFAULT false NOT NULL,
    "fechaCumplido" timestamp(3) without time zone,
    "notaAudioId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.compromisos OWNER TO asistente;

--
-- Name: compromisos_id_seq; Type: SEQUENCE; Schema: public; Owner: asistente
--

CREATE SEQUENCE public.compromisos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.compromisos_id_seq OWNER TO asistente;

--
-- Name: compromisos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: asistente
--

ALTER SEQUENCE public.compromisos_id_seq OWNED BY public.compromisos.id;


--
-- Name: destrezas; Type: TABLE; Schema: public; Owner: asistente
--

CREATE TABLE public.destrezas (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    categoria character varying(50),
    nivel_actual integer,
    descripcion text,
    costo_energetico public."TipoEnergia",
    mejor_momento_dia text[],
    requiere_flow boolean,
    notas_contexto text
);


ALTER TABLE public.destrezas OWNER TO asistente;

--
-- Name: TABLE destrezas; Type: COMMENT; Schema: public; Owner: asistente
--

COMMENT ON TABLE public.destrezas IS 'Habilidades y capacidades de Guillermo con metadata de contexto de ejecución';


--
-- Name: destrezas_id_seq; Type: SEQUENCE; Schema: public; Owner: asistente
--

CREATE SEQUENCE public.destrezas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.destrezas_id_seq OWNER TO asistente;

--
-- Name: destrezas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: asistente
--

ALTER SEQUENCE public.destrezas_id_seq OWNED BY public.destrezas.id;


--
-- Name: dificultades; Type: TABLE; Schema: public; Owner: asistente
--

CREATE TABLE public.dificultades (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    categoria character varying(50),
    nivel_impacto integer,
    descripcion text,
    estrategia_mitigacion text
);


ALTER TABLE public.dificultades OWNER TO asistente;

--
-- Name: TABLE dificultades; Type: COMMENT; Schema: public; Owner: asistente
--

COMMENT ON TABLE public.dificultades IS 'Desafíos personales de Guillermo con estrategias de mitigación';


--
-- Name: dificultades_id_seq; Type: SEQUENCE; Schema: public; Owner: asistente
--

CREATE SEQUENCE public.dificultades_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dificultades_id_seq OWNER TO asistente;

--
-- Name: dificultades_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: asistente
--

ALTER SEQUENCE public.dificultades_id_seq OWNED BY public.dificultades.id;


--
-- Name: ideas_capturadas; Type: TABLE; Schema: public; Owner: asistente
--

CREATE TABLE public.ideas_capturadas (
    id integer NOT NULL,
    titulo text NOT NULL,
    descripcion text,
    categoria text,
    implementada boolean DEFAULT false NOT NULL,
    "fechaImplementacion" timestamp(3) without time zone,
    "notaAudioId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    proyecto_estrategico_id integer
);


ALTER TABLE public.ideas_capturadas OWNER TO asistente;

--
-- Name: ideas_id_seq; Type: SEQUENCE; Schema: public; Owner: asistente
--

CREATE SEQUENCE public.ideas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ideas_id_seq OWNER TO asistente;

--
-- Name: ideas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: asistente
--

ALTER SEQUENCE public.ideas_id_seq OWNED BY public.ideas_capturadas.id;


--
-- Name: logs_generacion_ia; Type: TABLE; Schema: public; Owner: asistente
--

CREATE TABLE public.logs_generacion_ia (
    id integer NOT NULL,
    proyecto_id integer,
    tipo_generacion character varying(50),
    modelo_ia character varying(100),
    tokens_usados integer,
    prompt text,
    respuesta text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.logs_generacion_ia OWNER TO asistente;

--
-- Name: logs_generacion_ia_id_seq; Type: SEQUENCE; Schema: public; Owner: asistente
--

CREATE SEQUENCE public.logs_generacion_ia_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.logs_generacion_ia_id_seq OWNER TO asistente;

--
-- Name: logs_generacion_ia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: asistente
--

ALTER SEQUENCE public.logs_generacion_ia_id_seq OWNED BY public.logs_generacion_ia.id;


--
-- Name: misiones_vida; Type: TABLE; Schema: public; Owner: asistente
--

CREATE TABLE public.misiones_vida (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    descripcion text,
    vision text,
    prioridad integer
);


ALTER TABLE public.misiones_vida OWNER TO asistente;

--
-- Name: TABLE misiones_vida; Type: COMMENT; Schema: public; Owner: asistente
--

COMMENT ON TABLE public.misiones_vida IS 'Roles de vida y propósitos de Guillermo a largo plazo';


--
-- Name: misiones_vida_id_seq; Type: SEQUENCE; Schema: public; Owner: asistente
--

CREATE SEQUENCE public.misiones_vida_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.misiones_vida_id_seq OWNER TO asistente;

--
-- Name: misiones_vida_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: asistente
--

ALTER SEQUENCE public.misiones_vida_id_seq OWNED BY public.misiones_vida.id;


--
-- Name: motivos_personales; Type: TABLE; Schema: public; Owner: asistente
--

CREATE TABLE public.motivos_personales (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    descripcion text,
    icono character varying(20),
    peso_personal integer
);


ALTER TABLE public.motivos_personales OWNER TO asistente;

--
-- Name: TABLE motivos_personales; Type: COMMENT; Schema: public; Owner: asistente
--

COMMENT ON TABLE public.motivos_personales IS 'Motivaciones que impulsan a Guillermo a llevar adelante proyectos';


--
-- Name: motivos_personales_id_seq; Type: SEQUENCE; Schema: public; Owner: asistente
--

CREATE SEQUENCE public.motivos_personales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.motivos_personales_id_seq OWNER TO asistente;

--
-- Name: motivos_personales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: asistente
--

ALTER SEQUENCE public.motivos_personales_id_seq OWNED BY public.motivos_personales.id;


--
-- Name: notas_audio; Type: TABLE; Schema: public; Owner: asistente
--

CREATE TABLE public.notas_audio (
    id integer NOT NULL,
    "transcripcionId" integer NOT NULL,
    "transcripcionCompleta" text NOT NULL,
    "archivoAudioUrl" text,
    "resumenEjecutivo" text,
    "fechaGrabacion" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    procesado boolean DEFAULT false NOT NULL,
    "tipoDetectado" text,
    "confianzaDeteccion" double precision,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.notas_audio OWNER TO asistente;

--
-- Name: notas_audio_id_seq; Type: SEQUENCE; Schema: public; Owner: asistente
--

CREATE SEQUENCE public.notas_audio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notas_audio_id_seq OWNER TO asistente;

--
-- Name: notas_audio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: asistente
--

ALTER SEQUENCE public.notas_audio_id_seq OWNED BY public.notas_audio.id;


--
-- Name: proyectos_estrategicos; Type: TABLE; Schema: public; Owner: asistente
--

CREATE TABLE public.proyectos_estrategicos (
    id integer NOT NULL,
    nombre character varying(200) NOT NULL,
    descripcion text,
    areas_ids integer[],
    motivos_ids integer[],
    destrezas_requeridas_ids integer[],
    dificultades_ids integer[],
    misiones_ids integer[],
    justificacion_estrategica jsonb,
    objetivos_smart jsonb,
    fecha_inicio date,
    fecha_fin_estimada date,
    estado public."TipoEstadoProyecto" DEFAULT 'idea'::public."TipoEstadoProyecto" NOT NULL,
    prioridad_global numeric(3,2),
    score_motivacional numeric(3,2),
    score_alineacion numeric(3,2),
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.proyectos_estrategicos OWNER TO asistente;

--
-- Name: proyectos_estrategicos_id_seq; Type: SEQUENCE; Schema: public; Owner: asistente
--

CREATE SEQUENCE public.proyectos_estrategicos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.proyectos_estrategicos_id_seq OWNER TO asistente;

--
-- Name: proyectos_estrategicos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: asistente
--

ALTER SEQUENCE public.proyectos_estrategicos_id_seq OWNED BY public.proyectos_estrategicos.id;


--
-- Name: registros; Type: TABLE; Schema: public; Owner: asistente
--

CREATE TABLE public.registros (
    id integer NOT NULL,
    descripcion text NOT NULL,
    "duracionHoras" double precision,
    proyecto text,
    "personasInvolucradas" text[],
    categoria public."Categoria" DEFAULT 'TRABAJO'::public."Categoria" NOT NULL,
    "fechaActividad" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "notaAudioId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.registros OWNER TO asistente;

--
-- Name: registros_id_seq; Type: SEQUENCE; Schema: public; Owner: asistente
--

CREATE SEQUENCE public.registros_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.registros_id_seq OWNER TO asistente;

--
-- Name: registros_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: asistente
--

ALTER SEQUENCE public.registros_id_seq OWNED BY public.registros.id;


--
-- Name: subtareas; Type: TABLE; Schema: public; Owner: asistente
--

CREATE TABLE public.subtareas (
    id integer NOT NULL,
    tarea_estrategica_id integer NOT NULL,
    titulo character varying(255) NOT NULL,
    completada boolean DEFAULT false NOT NULL,
    tiempo_estimado_minutos integer,
    moscow public."TipoMoscow",
    destreza_principal_id integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.subtareas OWNER TO asistente;

--
-- Name: subtareas_id_seq; Type: SEQUENCE; Schema: public; Owner: asistente
--

CREATE SEQUENCE public.subtareas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subtareas_id_seq OWNER TO asistente;

--
-- Name: subtareas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: asistente
--

ALTER SEQUENCE public.subtareas_id_seq OWNED BY public.subtareas.id;


--
-- Name: tareas; Type: TABLE; Schema: public; Owner: asistente
--

CREATE TABLE public.tareas (
    id integer NOT NULL,
    titulo text NOT NULL,
    descripcion text,
    "fechaVencimiento" timestamp(3) without time zone,
    prioridad public."Prioridad" DEFAULT 'MEDIA'::public."Prioridad" NOT NULL,
    completada boolean DEFAULT false NOT NULL,
    "fechaCompletada" timestamp(3) without time zone,
    "notaAudioId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    proyecto_estrategico_id integer
);


ALTER TABLE public.tareas OWNER TO asistente;

--
-- Name: tareas_estrategicas; Type: TABLE; Schema: public; Owner: asistente
--

CREATE TABLE public.tareas_estrategicas (
    id integer NOT NULL,
    proyecto_id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    descripcion text,
    orden integer,
    moscow public."TipoMoscow",
    tiempo_estimado_horas integer,
    nivel_riesgo public."TipoRiesgo",
    prioridad_velocidad_perfeccion public."TipoEnfoque",
    estado public."TipoEstadoTarea" DEFAULT 'por_hacer'::public."TipoEstadoTarea" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.tareas_estrategicas OWNER TO asistente;

--
-- Name: tareas_estrategicas_id_seq; Type: SEQUENCE; Schema: public; Owner: asistente
--

CREATE SEQUENCE public.tareas_estrategicas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tareas_estrategicas_id_seq OWNER TO asistente;

--
-- Name: tareas_estrategicas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: asistente
--

ALTER SEQUENCE public.tareas_estrategicas_id_seq OWNED BY public.tareas_estrategicas.id;


--
-- Name: tareas_id_seq; Type: SEQUENCE; Schema: public; Owner: asistente
--

CREATE SEQUENCE public.tareas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tareas_id_seq OWNER TO asistente;

--
-- Name: tareas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: asistente
--

ALTER SEQUENCE public.tareas_id_seq OWNED BY public.tareas.id;


--
-- Name: areas_vida id; Type: DEFAULT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.areas_vida ALTER COLUMN id SET DEFAULT nextval('public.areas_vida_id_seq'::regclass);


--
-- Name: compromisos id; Type: DEFAULT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.compromisos ALTER COLUMN id SET DEFAULT nextval('public.compromisos_id_seq'::regclass);


--
-- Name: destrezas id; Type: DEFAULT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.destrezas ALTER COLUMN id SET DEFAULT nextval('public.destrezas_id_seq'::regclass);


--
-- Name: dificultades id; Type: DEFAULT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.dificultades ALTER COLUMN id SET DEFAULT nextval('public.dificultades_id_seq'::regclass);


--
-- Name: ideas_capturadas id; Type: DEFAULT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.ideas_capturadas ALTER COLUMN id SET DEFAULT nextval('public.ideas_id_seq'::regclass);


--
-- Name: logs_generacion_ia id; Type: DEFAULT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.logs_generacion_ia ALTER COLUMN id SET DEFAULT nextval('public.logs_generacion_ia_id_seq'::regclass);


--
-- Name: misiones_vida id; Type: DEFAULT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.misiones_vida ALTER COLUMN id SET DEFAULT nextval('public.misiones_vida_id_seq'::regclass);


--
-- Name: motivos_personales id; Type: DEFAULT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.motivos_personales ALTER COLUMN id SET DEFAULT nextval('public.motivos_personales_id_seq'::regclass);


--
-- Name: notas_audio id; Type: DEFAULT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.notas_audio ALTER COLUMN id SET DEFAULT nextval('public.notas_audio_id_seq'::regclass);


--
-- Name: proyectos_estrategicos id; Type: DEFAULT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.proyectos_estrategicos ALTER COLUMN id SET DEFAULT nextval('public.proyectos_estrategicos_id_seq'::regclass);


--
-- Name: registros id; Type: DEFAULT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.registros ALTER COLUMN id SET DEFAULT nextval('public.registros_id_seq'::regclass);


--
-- Name: subtareas id; Type: DEFAULT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.subtareas ALTER COLUMN id SET DEFAULT nextval('public.subtareas_id_seq'::regclass);


--
-- Name: tareas id; Type: DEFAULT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.tareas ALTER COLUMN id SET DEFAULT nextval('public.tareas_id_seq'::regclass);


--
-- Name: tareas_estrategicas id; Type: DEFAULT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.tareas_estrategicas ALTER COLUMN id SET DEFAULT nextval('public.tareas_estrategicas_id_seq'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: asistente
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
809daaec-2540-41ad-92e8-31ff1155e570	f0336f4d1ecbadb406d7d195464ba49cddd69eb1104d5507905e8817f1dac5d2	\N	20251201231235_init_mateos_v2_schema	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20251201231235_init_mateos_v2_schema\n\nDatabase error code: 42710\n\nDatabase error:\nERROR: type "Prioridad" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42710), message: "type \\"Prioridad\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("typecmds.c"), line: Some(1167), routine: Some("DefineEnum") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20251201231235_init_mateos_v2_schema"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20251201231235_init_mateos_v2_schema"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260	2025-12-02 03:00:33.504248+00	2025-12-02 03:00:16.441466+00	0
d2f93546-2c73-4dbd-a37a-563d36364c0b	f0336f4d1ecbadb406d7d195464ba49cddd69eb1104d5507905e8817f1dac5d2	2025-12-02 03:00:33.510618+00	20251201231235_init_mateos_v2_schema		\N	2025-12-02 03:00:33.510618+00	0
\.


--
-- Data for Name: areas_vida; Type: TABLE DATA; Schema: public; Owner: asistente
--

COPY public.areas_vida (id, nombre, descripcion, color_hex, orden_visualizacion, activa) FROM stdin;
1	involucrate	Plataforma de voluntariado corporativo y gestión de impacto social	#FF6B6B	1	t
2	involucrarse	Proyectos sociales directos y coordinación de iniciativas comunitarias	#4ECDC4	2	t
3	mateos	Metodología de gestión personal y sistema de decisiones (este proyecto)	#95E1D3	3	t
4	marcaPersonal	Construcción de marca, contenido, redes sociales y posicionamiento	#F38181	4	t
5	tdahAACC	Exploración y gestión de TDAH y Altas Capacidades	#AA96DA	5	t
6	fibras	Salud mental, bienestar emocional y terapia	#FCBAD3	6	t
7	gyermekClub	Proyectos con niños, educación y desarrollo infantil	#FFFFD2	7	t
8	murga	Expresión artística, murga, música y performance	#FFD3B6	8	t
9	placita	Proyectos barriales, espacio público y comunidad local	#A8E6CF	9	t
10	cfEscuela	Proyectos en escuela de los hijos	#FFB6C1	10	t
11	cfJardin	Proyectos en jardín de infantes	#DDA0DD	11	t
12	salud	Salud física, ejercicio, alimentación y bienestar	#98D8C8	12	t
13	finanzas	Gestión financiera personal, inversiones y economía	#F7DC6F	13	t
14	familia	Tiempo familiar, paternidad y relaciones	#FF9AA2	14	t
\.


--
-- Data for Name: compromisos; Type: TABLE DATA; Schema: public; Owner: asistente
--

COPY public.compromisos (id, titulo, descripcion, "personaNombre", "fechaLimite", "yoMeComprometi", cumplido, "fechaCumplido", "notaAudioId", "createdAt", "updatedAt") FROM stdin;
1	Reunión con UQ Business School	Tengo una reunión con UQ Business School el viernes 7 a las 11 de la mañana, les envié un link de Google Meets.	UQ Business School	2025-11-07 11:00:00	t	t	\N	3	2025-11-07 02:39:40.643	2025-11-07 02:39:40.643
2	Participar en el grupito de Fe y Alegría	Le dije que sí a Pablo de Fiberas para participar en el grupito de Fe y Alegría para la puesta en marcha de eso.	Pablo de Fiberas	2025-11-06 00:00:00	t	f	\N	20	2025-11-07 21:31:12.265	2025-11-07 21:31:12.265
3	Hablar con el arquitecto	Mañana tengo que ir al municipio a hablar con el arquitecto para preguntarle y poder pedirle cuáles son los planos y las instrucciones que le pasó a la empresa constructora.	arquitecto	2025-11-18 00:00:00	t	f	\N	38	2025-11-17 17:15:15.98	2025-11-17 17:15:15.98
\.


--
-- Data for Name: destrezas; Type: TABLE DATA; Schema: public; Owner: asistente
--

COPY public.destrezas (id, nombre, categoria, nivel_actual, descripcion, costo_energetico, mejor_momento_dia, requiere_flow, notas_contexto) FROM stdin;
1	empatía	Social	9	Capacidad de conectar emocionalmente con otros	media	{cualquier_momento}	f	Natural, no me cansa
2	asertivo	Social	7	Expresar opiniones y límites con claridad	media	{mañana,tarde}	f	Requiere estar descansado para no caer en agresividad
3	confianza	Social	8	Generar confianza en otros, ser confiable	baja	{cualquier_momento}	f	Se construye con consistencia
4	buenMediador	Social	8	Facilitar acuerdos y resolver conflictos	alta	{mañana}	f	Requiere paciencia y energía emocional
5	oratoria	Social	7	Hablar en público con claridad y persuasión	alta	{mañana,tarde}	f	Mejor con preparación previa
6	comunicación	Social	8	Transmitir ideas claramente, escuchar activamente	media	{cualquier_momento}	f	Core skill, uso constante
7	manejoDeGrupos	Social	8	Coordinar y facilitar dinámicas grupales	alta	{mañana,tarde}	f	Requiere energía social alta
8	liderazgo	Gestión	8	Inspirar y guiar equipos hacia objetivos	alta	{mañana}	f	Mejor en días con alta energía
9	buenLíderPersonal	Gestión	8	Gestionar mi propia vida y proyectos	media	{mañana}	t	Requiere claridad mental
10	hacerPlanes	Gestión	9	Diseñar estrategias y roadmaps	media	{mañana,noche}	t	Me gusta y me sale natural
11	ordenDeIdeas	Gestión	8	Estructurar pensamientos complejos	media	{mañana}	t	Necesito tranquilidad
12	voluntariadoGestion	Gestión	9	Coordinar voluntarios y proyectos sociales	alta	{mañana,tarde}	f	Expertise profesional
13	inteligenciaArtificial	Técnica	8	Crear automatizaciones y usar APIs de IA	pico	{mañana_temprano,noche}	t	Requiere máxima concentración
14	desarrolloCodigo	Técnica	7	Programar en Python, JavaScript, TypeScript	pico	{mañana_temprano}	t	Necesito flow completo, 2+ horas
15	diseñoFuncional	Técnica	7	Diseñar arquitecturas de sistemas	alta	{mañana}	t	Requiere pensamiento profundo
16	tecnologia	Técnica	8	Entender y usar nuevas tecnologías	media	{cualquier_momento}	f	Aprendizaje continuo
17	teoríaDeComputadoras	Técnica	6	Fundamentos de ciencias de la computación	alta	{mañana}	t	Requiere estudio concentrado
18	webDesign	Técnica	6	Diseñar interfaces web	media	{tarde,noche}	f	Creativo, no muy técnico
19	UX	Técnica	7	Diseño de experiencia de usuario	media	{tarde}	f	Combina empatía y diseño
20	designThinking	Técnica	8	Metodología de innovación centrada en usuario	media	{mañana,tarde}	f	Framework que uso mucho
21	producción	Creativa	7	Producir eventos, proyectos, contenido	alta	{cualquier_momento}	f	Coordinar múltiples elementos
22	ediciónDeVideo	Creativa	6	Editar videos	alta	{tarde,noche}	t	Requiere bloques largos
23	ediciónDeAudio	Creativa	7	Editar audio y podcasts	media	{tarde,noche}	t	Me relaja más que video
24	fotografía	Creativa	6	Capturar fotos de calidad	baja	{cualquier_momento}	f	Tarea ligera
25	iluminación	Creativa	5	Diseñar iluminación para eventos/video	media	{tarde}	f	Técnico pero creativo
26	copyEscritura	Creativa	7	Escribir textos persuasivos	media	{mañana,noche}	t	Requiere concentración
27	danza	Artística	6	Bailar, coreografías	alta	{tarde,noche}	f	Energético, me recarga
28	musica	Artística	6	Tocar instrumentos, componer	media	{tarde,noche}	f	Expresión personal
29	canto	Artística	6	Cantar	media	{cualquier_momento}	f	Liberador
30	guitarra	Artística	5	Tocar guitarra	media	{tarde,noche}	f	Requiere práctica
31	ukelele	Artística	6	Tocar ukelele	baja	{cualquier_momento}	f	Instrumento ligero
32	rítmo	Artística	7	Sentido del ritmo	baja	{cualquier_momento}	f	Natural
33	coreografías	Artística	6	Crear coreografías de danza/murga	alta	{tarde}	f	Requiere creatividad e imaginación
34	actuarTeatro	Artística	6	Actuar, performance teatral	alta	{tarde,noche}	f	Requiere desinhibición
35	chistes	Artística	7	Hacer reír, humor	baja	{cualquier_momento}	f	Natural, me sale espontáneo
36	solucionesDriven	Cognitiva	9	Enfoque en soluciones, no problemas	media	{cualquier_momento}	f	Mindset natural
37	ingenio	Cognitiva	9	Encontrar soluciones creativas con recursos limitados	media	{mañana,tarde}	f	Fortaleza clave
38	pensamientoPropio	Cognitiva	9	Pensar críticamente, cuestionar status quo	media	{mañana,noche}	t	Requiere soledad y silencio
39	analisisCriticoDetallado	Cognitiva	8	Analizar en profundidad	alta	{mañana}	t	Requiere concentración máxima
40	pensamientoRamificado	Cognitiva	9	Ver múltiples caminos y conexiones	media	{mañana}	f	TDAH advantage
41	comprensionDeSystemas	Cognitiva	9	Ver el todo, entender interdependencias	alta	{mañana}	t	Pensamiento sistémico natural
42	pensamientoEnSistemas	Cognitiva	9	Modelar sistemas complejos	alta	{mañana}	t	Core skill para proyectos
43	esquemas	Cognitiva	8	Crear diagramas y modelos visuales	media	{mañana,tarde}	f	Ayuda a pensar mejor
44	conocimientoFilosofía	Conocimiento	7	Filosofía, historia del pensamiento	media	{noche}	f	Lectura y reflexión
45	existencialismo	Conocimiento	8	Filosofía existencialista	media	{noche}	f	Resonancia personal
46	conocimientoPsicología	Conocimiento	8	Psicología, comportamiento humano	media	{cualquier_momento}	f	Estudio continuo
47	eneagrama	Conocimiento	7	Sistema de personalidad Eneagrama	baja	{cualquier_momento}	f	Herramienta de autoconocimiento
48	conocimientoEconomía	Conocimiento	6	Economía y macroeconomía	alta	{mañana}	t	Requiere concentración
49	conocimientoFinanzas	Conocimiento	6	Finanzas personales y empresariales	media	{mañana,tarde}	f	Aprendizaje en progreso
50	conocimientoNegocios	Conocimiento	7	Estrategia de negocios, emprendimiento	media	{mañana,tarde}	f	Experiencia práctica
51	matematicas	Conocimiento	7	Matemáticas, lógica	alta	{mañana}	t	Requiere mente fresca
52	carpintería	Práctica	5	Trabajar con madera	alta	{mañana,tarde}	f	Físico, requiere energía
53	bioconstrucción	Práctica	5	Construcción sustentable	alta	{mañana,tarde}	f	Físico y técnico
54	cocinero	Práctica	6	Cocinar	media	{tarde,noche}	f	Tarea cotidiana
55	atleta	Práctica	6	Deportes, actividad física	alta	{mañana,tarde}	f	Me recarga energéticamente
56	facilidadDeportes	Práctica	7	Aprender deportes rápidamente	media	{cualquier_momento}	f	Natural
57	facilidadParaCiencias	Práctica	8	Entender conceptos científicos	alta	{mañana}	t	Requiere concentración
58	pedagogía	Educativa	7	Enseñar, facilitar aprendizaje	media	{mañana,tarde}	f	Disfruto enseñar
59	enseñanza	Educativa	7	Transmitir conocimiento efectivamente	media	{mañana,tarde}	f	Paciencia y claridad
60	recreacion	Educativa	8	Diseñar actividades recreativas	media	{tarde}	f	Creativo y energético
61	campamentero	Educativa	7	Organizar campamentos, actividades outdoor	alta	{cualquier_momento}	f	Requiere energía y coordinación
62	esfuerzo	Personal	8	Capacidad de trabajar duro cuando es necesario	alta	{mañana}	f	Intensidad cuando hace falta
63	podcast	Media	6	Crear y producir podcasts	media	{tarde,noche}	f	Conversacional
64	redesSociales	Media	6	Gestionar redes sociales	baja	{tarde,noche}	f	Tarea ligera
65	buenPadre	Personal	8	Ser presente y buen padre	alta	{tarde,noche}	f	Requiere energía emocional
66	impactoSocialAmbiental	Social	9	Diseñar proyectos con impacto positivo	media	{mañana,tarde}	f	Propósito de vida
67	causasSociales	Social	9	Trabajo en causas sociales	media	{cualquier_momento}	f	Motivación intrínseca
68	meditar	Personal	6	Meditar, mindfulness	relax	{mañana_temprano,noche}	f	Me recarga
69	titulosAcademicos	Conocimiento	7	Formación académica formal	media	{cualquier_momento}	f	Base de conocimiento
\.


--
-- Data for Name: dificultades; Type: TABLE DATA; Schema: public; Owner: asistente
--

COPY public.dificultades (id, nombre, categoria, nivel_impacto, descripcion, estrategia_mitigacion) FROM stdin;
1	revisarMails	Temporal	8	Procrastinación en revisar y responder emails. Se acumulan.	Bloquear 30 min diarios específicos (15:00-15:30). Usar templates de respuesta. Regla 2 minutos: si toma menos, responder ya.
2	constancia	Emocional	9	Dificultad para mantener constancia en hábitos y tareas repetitivas. TDAH.	Sistemas de accountability (check-ins con alguien). Vincular hábito a recompensa inmediata. Usar Habit Tracker visual. No confiar solo en motivación, crear fricción para NO hacer.
3	exponerme	Emocional	7	Miedo a exponerme públicamente, mostrar vulnerabilidad o imperfección.	Empezar con audiencias pequeñas y seguras. Recordar que la perfección paraliza. Compartir proceso, no solo resultados. Terapia para trabajar miedo al juicio.
4	responderRedes	Social	7	Procrastinación en responder mensajes de redes sociales. Inbox de WhatsApp, LinkedIn, Instagram con mensajes sin leer.	Igualar estrategia que emails: bloque de 20 min diarios. Usar respuestas rápidas. Comunicar "respondo lento" en bio. Delegar si es posible.
5	mantenerPromesas	Social	8	Sobre-comprometerme y luego no cumplir promesas. Decir "sí" cuando debería decir "no".	Regla: ante propuesta nueva, decir "Déjame revisarlo y te confirmo". Calcular tiempo real × 1.5. Aprender a decir no con gracia. Recordar costo de oportunidad.
6	darPasoAdelante	Emocional	8	Paralización ante incertidumbre. Perfeccionismo que impide empezar.	Mantra: "Done is better than perfect". Prototipar rápido. Timebox de decisiones (máximo X tiempo para decidir, luego ejecutar). Recordar que se aprende haciendo.
7	ordenar	Práctica	7	Dificultad para mantener espacios físicos ordenados. TDAH.	Sistema de "un lugar para cada cosa". Reducir cantidad de objetos (minimalismo). Ordenar al final del día 10 minutos. No acumular, tirar/donar rápido.
8	limpiar	Práctica	6	Procrastinación en tareas de limpieza.	Música alegre mientras limpio. Técnica Pomodoro (25 min limpieza). Recompensa post-limpieza (café, serie). Si es posible, delegar o contratar.
9	recoger	Práctica	7	Dejar cosas fuera de lugar. No recoger en el momento.	Regla "one-touch": si toco algo, lo guardo ya. Baskets/cajas por área para "tirar" cosas temporalmente. Recordar que recoger ahora = 10 segundos, después = 5 minutos de buscar.
\.


--
-- Data for Name: ideas_capturadas; Type: TABLE DATA; Schema: public; Owner: asistente
--

COPY public.ideas_capturadas (id, titulo, descripcion, categoria, implementada, "fechaImplementacion", "notaAudioId", "createdAt", "updatedAt", proyecto_estrategico_id) FROM stdin;
1	Mejora en la gestión de proyectos	Necesidad de tener una tabla accesible desde nocodb para cambiar nombres de proyectos y gestionar personas involucradas, incluyendo la identificación de cada persona por su ID en relación a los proyectos.	mejora	f	\N	10	2025-11-07 04:54:27.038	2025-11-07 04:54:27.038	\N
2	Compra de máquina de sublimación	Pensé en comprar una máquina de sublimación y agregarlo en el ande, como, no sé.	producto	f	\N	11	2025-11-07 04:55:09.283	2025-11-07 04:55:09.283	\N
3	Implementar tabla de comunicación para proyectos	Proponer la creación de una tabla que defina el tipo de contenido y la línea de comunicación permitida para los proyectos, especificando qué información se puede compartir y qué no.	estrategia	f	\N	133	2025-12-01 18:57:33.659	2025-12-01 18:57:33.659	\N
\.


--
-- Data for Name: logs_generacion_ia; Type: TABLE DATA; Schema: public; Owner: asistente
--

COPY public.logs_generacion_ia (id, proyecto_id, tipo_generacion, modelo_ia, tokens_usados, prompt, respuesta, created_at) FROM stdin;
\.


--
-- Data for Name: misiones_vida; Type: TABLE DATA; Schema: public; Owner: asistente
--

COPY public.misiones_vida (id, nombre, descripcion, vision, prioridad) FROM stdin;
1	facilitador_bondad	Facilitador de la ejecución de la bondad de los demás	Ser el puente que conecta la intención de ayudar con la acción concreta. Que cuando alguien piense "quiero hacer algo bueno", yo sea quien lo hace posible. Multiplicar el impacto social facilitando que miles de personas ejecuten su bondad.	10
2	momentador_herramientas	Momentador y creador de herramientas para una sociedad más comunicada	Crear sistemas y herramientas (digitales, metodológicas, conceptuales) que ayuden a las personas a comunicarse mejor, entenderse mejor, y coordinarse mejor. Que mis herramientas sean usadas por miles para mejorar su comunicación.	9
3	creador_plataformas	Creador de plataformas y proyectos para que las personas desarrollen su potencial	Diseñar espacios (físicos, digitales, conceptuales) donde las personas puedan crecer, aprender, y convertirse en su mejor versión. Que al menos 10,000 personas hayan desarrollado su potencial gracias a mis plataformas.	9
4	creador_modelos_mentales	Creador de modelos mentales	Crear frameworks, sistemas de pensamiento, y modelos mentales que ayuden a otros a pensar mejor, decidir mejor, y vivir mejor. Que mis modelos sean enseñados y replicados por otros.	8
5	money_maker	Money Maker - Generador de valor económico sostenible	Crear ingresos suficientes para vivir bien, sostener a mi familia, y reinvertir en proyectos de impacto. Llegar a $10k USD/mes recurrentes con proyectos que amo. Libertad financiera sin sacrificar propósito.	8
6	creador_contenido	Creador de contenido que inspira y educa	Crear contenido (escrito, audio, video) que inspire a otros a actuar, a pensar diferente, a crear impacto. Tener una audiencia de 10,000+ personas que esperan mi contenido y se transforman con él.	7
\.


--
-- Data for Name: motivos_personales; Type: TABLE DATA; Schema: public; Owner: asistente
--

COPY public.motivos_personales (id, nombre, descripcion, icono, peso_personal) FROM stdin;
1	impacto_social	Generar cambio positivo medible en la sociedad	🌍	10
2	desarrollo_personal	Aprender, crecer y expandir capacidades	📚	9
3	status_reconocimiento	Ganar autoridad y reconocimiento en el sector	⭐	7
4	desafio_intelectual	Resolver problemas complejos y salir de zona de confort	🧠	9
5	ingresos_sostenibilidad	Generar ingresos para sostenibilidad económica	💰	8
6	conexiones_red	Ampliar red de contactos valiosos	🤝	7
7	creatividad_expresion	Expresar creatividad y crear algo único	🎨	8
8	legado_trascendencia	Dejar algo que trascienda en el tiempo	🏛️	8
9	comunidad_pertenencia	Fortalecer lazos comunitarios y sentido de pertenencia	👥	9
10	experimentacion	Probar cosas nuevas, iterar, aprender haciendo	🔬	9
11	libertad_autonomia	Trabajar con libertad de decisión y creatividad	🦅	9
12	diversion_disfrute	Disfrutar el proceso, pasarla bien	😄	8
\.


--
-- Data for Name: notas_audio; Type: TABLE DATA; Schema: public; Owner: asistente
--

COPY public.notas_audio (id, "transcripcionId", "transcripcionCompleta", "archivoAudioUrl", "resumenEjecutivo", "fechaGrabacion", procesado, "tipoDetectado", "confianzaDeteccion", "createdAt", "updatedAt") FROM stdin;
1	999	Teo llamar a María mañana a las 3pm para revisar el proyecto	https://example.com/audio.mp3	\N	2025-11-07 01:36:29.868	t	tarea	1	2025-11-07 01:36:29.868	2025-11-07 01:36:32.208
122	68	Juan, después fui a Valdivia a comprar TNT para la escuela.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_68_1763420230700.ogg	\N	2025-11-17 22:57:12.691	t	registro	0.8	2025-11-17 22:57:12.691	2025-11-17 22:57:14.916
2	9	Teo, hay que armar y escribir la sección 1 del formulario de capital Semilla de Andes.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_9_1762483130770.ogg	\N	2025-11-07 02:38:53.212	t	tarea	0.75	2025-11-07 02:38:53.212	2025-11-07 02:38:56.192
3	10	Compa, tengo una reunión con UQ Business School el viernes 7 a las 11 de la mañana, les envié un link de Google Meets	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_10_1762483175413.ogg	\N	2025-11-07 02:39:37.64	t	compromiso	0.8333333333333334	2025-11-07 02:39:37.64	2025-11-07 02:39:40.65
123	69	Juan, de tarde, antes de ir a buscar a Feli, hice un escrito para enviar a los padres desde la Comisión Fomento como fin de año.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_69_1763420256289.ogg	\N	2025-11-17 22:57:38.656	t	registro	0.8	2025-11-17 22:57:38.656	2025-11-17 22:57:40.835
4	11	Teo, tengo que escribirle a Diego Sastre mañana al mediodía para revisar a ver si me van a apoyar desde Fibras o si no.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_11_1762483226266.ogg	\N	2025-11-07 02:40:27.869	t	tarea	0.75	2025-11-07 02:40:27.869	2025-11-07 02:40:29.86
5	12	Juan, estuve las últimas tres horas armando dos cosas a la vez, la primera es Mateos que ahora estoy usando y la otra es llenado de un formulario postulación para ANDE	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_12_1762483312119.ogg	\N	2025-11-07 02:41:55.28	t	registro	0.8	2025-11-07 02:41:55.28	2025-11-07 02:41:57.691
124	70	Juan, fui a la ortodoncista a ver cómo le estaba yendo a Feli y a cambiar mi ortodoncia.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_70_1763420272013.ogg	\N	2025-11-17 22:57:54.497	t	registro	0.8	2025-11-17 22:57:54.497	2025-11-17 22:57:57.181
6	13	Juan, llevo Gaby con los niños y los tuve que bajar y ahí empecé a... me enganché con el celular y creo que perdí una hora entera mirando videítos	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_13_1762483346511.ogg	\N	2025-11-07 02:42:28.239	t	registro	0.8	2025-11-07 02:42:28.239	2025-11-07 02:42:29.694
7	14	Juan, hice mucha fuerza y escuché el mensaje que mandó Diego, ya se lo respondí, ya le dije que estoy haciendo el formulario este.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_14_1762483369011.ogg	\N	2025-11-07 02:42:52.284	t	registro	0.8	2025-11-07 02:42:52.284	2025-11-07 02:42:53.834
125	71	Juan, en el medio me sumé a la reunión de fe y alegría con el chatbot y pedí para poder generar un nuevo prompt.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_71_1763420294277.ogg	\N	2025-11-17 22:58:15.865	t	registro	0.8	2025-11-17 22:58:15.865	2025-11-17 22:58:17.854
8	15	Juan, hice toda la automatización, le agregué a Mateos la automatización de el resumen del día así que el viernes a las 8 estaría llegando la primera automatización con todo lo que se hizo en el día	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_15_1762489551172.ogg	\N	2025-11-07 04:25:54.908	t	registro	0.8	2025-11-07 04:25:54.908	2025-11-07 04:25:59.85
9	16	Teo, el viernes 7 de noviembre lo que tengo que hacer es agarrar la planilla de estrategias de social media que me mandó Metricool y tratar de llenarla como para poder empezar a generar acciones y contenido	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_16_1762489639280.ogg	\N	2025-11-07 04:27:23.76	t	tarea	0.75	2025-11-07 04:27:23.76	2025-11-07 04:27:26.596
126	72	Juan, cuando venía para acá también pasé a buscar medicamentos y a comprar una garrafa.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_72_1763420322937.ogg	\N	2025-11-17 22:58:44.795	t	registro	0.8	2025-11-17 22:58:44.795	2025-11-17 22:58:46.297
10	17	Idea, tengo que tener una tabla que pueda acceder desde acá desde nocodb para poder cambiar los nombres de los proyectos por ejemplo y poder cambiar también la parte de las personas etcétera, es decir que en verdad sería como una forma de que pueda hacer esos cambios y cuando dice personas involucradas por ejemplo en la tabla de registros ahí vamos a tener poner un id de persona que es z Diego capaz que se puede después arreglar un poco eso dependiendo del proyecto que Diego hay en ese proyecto y tratar de descubrir cuál es el id digamos de esa persona	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_17_1762491258485.ogg	\N	2025-11-07 04:54:25.376	t	idea	0.6	2025-11-07 04:54:25.376	2025-11-07 04:54:27.043
127	73	Juan, mientras tanto también escribí un escrito para Whatsapp para la rifa de mañana de la escuela.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_73_1763420341765.ogg	\N	2025-11-17 22:59:03.381	t	registro	0.8	2025-11-17 22:59:03.381	2025-11-17 22:59:05.075
128	74	Juan le contesté a Valentina para poder tener una reunión el miércoles a las de tarde.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_74_1763420365809.ogg	\N	2025-11-17 22:59:31.568	t	registro	1	2025-11-17 22:59:31.568	2025-11-17 22:59:33.209
129	75	Juan, estuve revisando la información del presupuesto participativo y aportando y hice un deep research para ver si realmente nos pueden o nos tienen que entregar los pliegos.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_75_1763420386157.ogg	\N	2025-11-17 22:59:47.98	t	registro	0.8	2025-11-17 22:59:47.98	2025-11-17 22:59:52.482
130	76	Bueno, hoy estuve mirando el supercampeonato de la revista y ya abrí a mí toda la parte de... de... de la historia y de por del final de la revista y así que yo al final no la voy a contar ahora porque voy a tener que accountar desde el principio	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_76_1763757480231.ogg	\N	2025-11-21 20:38:05.708	f	sin_clasificar	0	2025-11-21 20:38:05.708	2025-11-21 20:38:05.708
11	18	Idea, pensé en comprar una maquina de sublimación y agregarlo en el ande, como, no sé.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_18_1762491303751.ogg	\N	2025-11-07 04:55:07.117	t	idea	0.6	2025-11-07 04:55:07.117	2025-11-07 04:55:09.291
131	77	¡SUSCRÍBETE!	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_77_1763757495871.ogg	\N	2025-11-21 20:38:17.313	f	sin_clasificar	0	2025-11-21 20:38:17.313	2025-11-21 20:38:17.313
12	19	Tengo que escribirle a Adri mañana sí o sí	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_19_1762491336098.ogg	\N	2025-11-07 04:55:37.986	t	tarea	0.6	2025-11-07 04:55:37.986	2025-11-07 04:55:40.014
132	78	Debo cambiar de ruido.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_78_1763757507660.ogg	\N	2025-11-21 20:38:32.778	f	sin_clasificar	0	2025-11-21 20:38:32.778	2025-11-21 20:38:32.778
13	20	Tengo que hacer una automatización para cuando se envíe o llegue un mensaje de conexión enviar Whatsapp a la persona, a la ONG primero que nada.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_20_1762491427005.ogg	\N	2025-11-07 04:57:09.561	t	tarea	0.6	2025-11-07 04:57:09.561	2025-11-07 04:57:10.943
14	21	Juan, estuve trabajando de 9 a 11 en mejorar la postulación de ANDE con CLOUD y ahora me quedé sin tokens en CLOUD, pero tengo que seguir.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_21_1762530101480.ogg	\N	2025-11-07 15:41:44.614	t	registro	0.8	2025-11-07 15:41:44.614	2025-11-07 15:41:46.874
15	22	Juan, tuve reunión con la energía, al final se puede llevar adelante la postulación de fibras, tengo que, bueno, y nada, eso, hablamos un poco de todo y me contó que creo que lo final es que lo que tengo que presentar tiene que tener sentido para mi proyecto.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_22_1762530136130.ogg	\N	2025-11-07 15:42:18.753	t	registro	0.8	2025-11-07 15:42:18.753	2025-11-07 15:42:21.409
16	23	Teo, tengo que enviar las respuestas del proyecto de Andes al mail de Anaria y de Rochi y de Leo.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_23_1762530168027.ogg	\N	2025-11-07 15:42:50.622	t	tarea	0.75	2025-11-07 15:42:50.622	2025-11-07 15:42:53.25
17	24	Juan, tuve una reunión con Enzo y Germán de UCUBS donde me dijeron que estaban ayudando adelante del proyecto Re-Vincularse y me invitaron a participar en un Ateneo el 10 de Diciembre para que presente algo sobre el voluntariado y las personas mayores.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_24_1762530229215.ogg	\N	2025-11-07 15:43:53.081	t	registro	0.8	2025-11-07 15:43:53.081	2025-11-07 15:43:55.431
18	25	Teo, tengo que armar como un esquema de lo que voy a decir en Ateneo y estudiar un poco más sobre los proyectos que vienen.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_25_1762530285261.ogg	\N	2025-11-07 15:44:47.904	t	tarea	0.75	2025-11-07 15:44:47.904	2025-11-07 15:44:49.925
19	26	Teo, envié el mail a Rochi, Leo, Diego y Analia para avisar que estaba con este proyecto y dar el ok en este sentido y a ver si Rochi y Leo están dispuestos a hacer el esfuerzo.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_26_1762536991711.ogg	\N	2025-11-07 17:36:34.533	t	tarea	0.75	2025-11-07 17:36:34.533	2025-11-07 17:36:37.37
20	27	Compa, le dije que sí a Pablo de Fiberas para participar en el grupito de Fe y Alegría para la puesta en marcha de eso, así que bueno, voy a... el lunes tenemos una reunión a la hora que teníamos antes la reunión de alianzas	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_27_1762551064916.ogg	\N	2025-11-07 21:31:09.015	t	compromiso	0.8333333333333334	2025-11-07 21:31:09.015	2025-11-07 21:31:12.279
34	41	Teo, en proyecto involucrate, el paso que sigue es armar como la base de datos de POSGRES, llenar las tablas	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_41_1762639695658.ogg	\N	2025-11-08 22:08:19.181	t	tarea	0.75	2025-11-08 22:08:19.181	2025-11-17 17:15:05.995
21	28	Bueno, hoy estuve trabajando en la presentación para Andes y bajando un poco más a tierra todo y me da que... al final me dijeron de fibras que no me podían ayudar y me quedo ahí en la espera de si voy a hacer este... no sé todavía cómo voy a definir si voy a presentarme con otra IP o simplemente la dejo pasar	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_28_1762551134123.ogg	\N	2025-11-07 21:32:18.219	f	sin_clasificar	0	2025-11-07 21:32:18.219	2025-11-07 21:32:18.219
22	29	Juan, pasé también, fui a llevar a Feli a la práctica de fútbol de Mario, después pasé para casa. Pasé por casa, antes fui a comprar frutas y verduras en Los Patos. Y tenía que ir al dentista pero no llegué.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_29_1762551257709.ogg	\N	2025-11-07 21:34:20.611	t	registro	0.8	2025-11-07 21:34:20.611	2025-11-07 21:34:22.859
133	79	Idea, una de las cosas que podemos hacer también es poner una tabla de comunicación o de contenido para los proyectos, qué es lo que se puede decir y qué no, y qué es lo que, por dónde puede ir la información.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/12/audio_79_1764615447032.ogg	\N	2025-12-01 18:57:30.805	t	idea	0.6	2025-12-01 18:57:30.805	2025-12-01 18:57:33.667
23	30	Juan, mandé un mail bastante complejo a Analia, Rochi, y lo que fuere, toda la gente, para limpiar un poco mi... limpiar un poco, no sé, como que había recibido un mail de Analia, como que yo estaba apurando en las cosas y que... no sé, no se siente cómoda con lo que yo que sé, como si yo lo sentí un poco, como que me estaba diciendo que yo estaba apurando y en verdad lo único que quería era una confirmación sí, estaba apurando en la confirmación, pero era un tema de tiempos y que cualquier persona con empatía lo podría entender bueno, está	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_30_1762551311970.ogg	\N	2025-11-07 21:35:16.375	t	registro	0.8	2025-11-07 21:35:16.375	2025-11-07 21:35:19.361
24	31	Juan, un poco gasté, ahora estoy bastante enojado y perturbado digamos, así que no sé bien qué voy a hacer todavía para llevar adelante esto y no sabría decirte. Tengo que definir si tengo que ir a otra IP o si lo dejo pasar y sumarme en alguna otra oportunidad.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_31_1762551379566.ogg	\N	2025-11-07 21:36:23.113	t	registro	0.8	2025-11-07 21:36:23.113	2025-11-07 21:36:27.681
25	32	Bueno, me mandó un mensaje Álvaro y me dijo que me pasó el contacto de Karina, que es de Ruta de Impacto, que es una IP chiquitita, pero que capaz que le puede llegar a servir, y hablé con Nota y después le dije que la iba a contactar y también después fui a escribirle a Santi para contarle a ver que onda, como es el tema del aborto, como lo maneja todo eso, así que bueno, veremos.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_32_1762559778474.ogg	\N	2025-11-07 23:56:22.135	f	sin_clasificar	0	2025-11-07 23:56:22.135	2025-11-07 23:56:22.135
26	33	Juan, hoy de mañana estuve mirando los avances que venía y decidí al final posponer un poco la postulación para el anda y hacerlo después, capaz que también con fibras, así que bueno, ya mandé mail para avisar, conciliador y bueno, dije que tenía ganas de verlo como para la próxima instancia.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_33_1762621866656.ogg	\N	2025-11-08 17:11:10.078	t	registro	0.8	2025-11-08 17:11:10.078	2025-11-17 17:14:38.006
30	37	Juan, hoy, mañana, arreglé el puff y también puse cintas en el vidrio que estaba rajado.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_37_1762638096522.ogg	\N	2025-11-08 21:41:38.901	t	registro	0.8	2025-11-08 21:41:38.901	2025-11-17 17:14:52.634
32	39	Tengo que revisar la postulación de Álvaro y armarle ahí algo para que queden lindas las cosas de ella.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_39_1762638256886.ogg	\N	2025-11-08 21:44:18.936	t	tarea	0.6	2025-11-08 21:44:18.936	2025-11-17 17:14:59.869
33	40	Teo, hay que revisar de vuelta lo de idas y vueltas y lo del plato lleno y las cosas que tengo que hacer en realidad es...	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_40_1762639658800.ogg	\N	2025-11-08 22:07:40.956	t	tarea	0.75	2025-11-08 22:07:40.956	2025-11-17 17:15:03.144
28	35	Tengo que copiar la información que tengo en las otras bases de datos y pegarlas a la nueva base de datos de involucrajado	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_35_1762621929737.ogg	\N	2025-11-08 17:12:11.889	t	tarea	0.6	2025-11-08 17:12:11.889	2025-11-17 17:14:46.796
31	38	Juan, después enviamos, no, colgué el ropa y vinimos a tomar un helado con los niños y ahora estamos en una placita jugando, que hay una suerte de... pero hay cosas de inmigrantes, me encontré con llanices y bueno, estamos por acá.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_38_1762638131614.ogg	\N	2025-11-08 21:42:14.607	t	registro	0.8	2025-11-08 21:42:14.607	2025-11-17 17:14:56.591
27	34	Juan, estuve, vamos pues, estuve lavando platos y tratando de, bueno, lavando platos mientras que ponía, trataba de hacer el test de Involucra Hub de la base de datos y no pude. No quedó pronto ese test y lo que me quedé pensando es que ya lo digo.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_34_1762621913443.ogg	\N	2025-11-08 17:11:58.04	t	registro	0.8	2025-11-08 17:11:58.04	2025-11-17 17:14:41.647
29	36	Juan, cociné unos fideos para todos con huevo y tomate y también hice unos pepinos al vinagre y también lavé las frutas para que queden prontas para comer.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_36_1762621963259.ogg	\N	2025-11-08 17:12:45.482	t	registro	0.8	2025-11-08 17:12:45.482	2025-11-17 17:14:49.514
45	52	y de álvaro de verde urbano está fascinado por el trabajo que hice que en verdad me llevó tiempo sí que de hecho le dediqué mucho tiempo pero al mismo tiempo me dejó muy contento de que él estimara también el trabajo como así que bueno nada como quiero destacar también esa cualidad que tengo de poder presentar proyectos fuertes buenos por lo menos ahora	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_52_1762806555092.ogg	\N	2025-11-10 20:29:18.136	f	sin_clasificar	0	2025-11-10 20:29:18.136	2025-11-17 17:15:36.074
37	44	Juan, hoy estuve en la mañana en la unión de información fomento de la escuela y después fui con Yanela a la placita a hablar con las personas que estaban en la obra de la placita	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_44_1762804780125.ogg	\N	2025-11-10 19:59:46.066	t	registro	0.8	2025-11-10 19:59:46.066	2025-11-17 17:15:12.309
38	45	Compa, mañana tengo que ir al municipio a hablar con el arquitecto para preguntarle y poder pedirle cuáles son los planos y las instrucciones que le pasó a la empresa constructora.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_45_1762804798992.ogg	\N	2025-11-10 20:00:01.869	t	compromiso	0.8333333333333334	2025-11-10 20:00:01.869	2025-11-17 17:15:15.987
40	47	Juan, estuve revisando la parte de la contabilidad de fibras, que Leo había dicho que había algo mal, pero ya veo que Fabián ya lo resolvió, así que seguimos adelante.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_47_1762804869683.ogg	\N	2025-11-10 20:01:14.261	t	registro	0.8	2025-11-10 20:01:14.261	2025-11-17 17:15:22.633
41	48	Teo, me voy para Pixis ahora, cinco y media, a tener la reunión del proyecto Fe y Alegría con Diego y con Pablo.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_48_1762804897698.ogg	\N	2025-11-10 20:01:39.252	t	tarea	0.75	2025-11-10 20:01:39.252	2025-11-17 17:15:25.914
42	49	Teo, voy a enviar la presentación que armé para la ANDE de involucrarse a Analia y las personas que están en proyecto de impacto para poder empezar a trabajar desde ahí.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_49_1762804945779.ogg	\N	2025-11-10 20:02:27.99	t	tarea	0.75	2025-11-10 20:02:27.99	2025-11-17 17:15:29.142
43	50	Teo, se comunicaron una voluntaria que se había contactado con Hecho y que no le han contestado. Tengo que arreglar eso y contactarme con ellos a ver si recibieron el contacto.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_50_1762804966134.ogg	\N	2025-11-10 20:02:48.254	t	tarea	0.75	2025-11-10 20:02:48.254	2025-11-17 17:15:31.702
44	51	Teo, hoy de noche tengo murga también. De ocho y media a nueve a once.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_51_1762805011906.ogg	\N	2025-11-10 20:03:34.078	t	tarea	0.75	2025-11-10 20:03:34.078	2025-11-17 17:15:35.071
47	54	Bueno, solo para contar que el jueves estuve contactando con el municipio todo el tiempo para ver que me pase el proyecto bueno, el miércoles que fue 12 estuve de noche también armando la carta para hablar sobre y exponer en redes la parte de que no se están tomando en cuenta y que se está metiendo a la placita del barrio	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_54_1763236839984.ogg	\N	2025-11-15 20:00:43.958	f	sin_clasificar	0	2025-11-15 20:00:43.958	2025-11-17 17:15:40.121
46	53	Juan, fui al comunal a hablar con el arquitecto que no estaba, me dijeron que me iban a llamar cuando llegó cuando llegó volví a ir para allá y cuando se iba ya no estaba, estaba hablando con el alcalde y ahora hablé con la directora, llamé de vuelta a la directora, la directora me dice que cuando la llamé de vuelta que estaba en una reunión con el alcalde con Álvaro, el otro arquitecto, pero bueno seguimos en la búsqueda de contactar para, en la búsqueda de poder generar como, no, tener el pliego de eso, de lo que le pidieron a la empresa	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_53_1762885886487.ogg	\N	2025-11-11 18:31:30.875	t	registro	0.8	2025-11-11 18:31:30.875	2025-11-17 17:15:39.118
48	55	Después, el viernes, estuve ayudando en la parte del viaje por la 190, y estuve todo el día ahí, con poca gente.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_55_1763236861552.ogg	\N	2025-11-15 20:01:04.321	f	sin_clasificar	0	2025-11-15 20:01:04.321	2025-11-17 17:15:41.127
49	56	Juan, el viernes estuve en consulta con Sara y ahí le estuve comentando también sobre el tema de la frustración y cómo me impacta.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_56_1763236893506.ogg	\N	2025-11-15 20:01:35.297	t	registro	0.8	2025-11-15 20:01:35.297	2025-11-17 17:15:43.877
50	57	Juan, el viernes también estuve haciendo. Llevé a los niños al fútbol. Primero a lo de Mario, después al Palá y estuve jugando un poco al básquetbol en la cancha nueva.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_57_1763236917906.ogg	\N	2025-11-15 20:02:00.741	t	registro	0.8	2025-11-15 20:02:00.741	2025-11-17 17:15:47.413
51	58	Juan, después no tuve murga, así que volví a casa y dormí hasta tarde.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_58_1763236926477.ogg	\N	2025-11-15 20:02:08.622	t	registro	0.8	2025-11-15 20:02:08.622	2025-11-17 17:15:50.43
52	59	Juan, hoy fui a comprar el tarmo que me quedaba por comprar con el mate y estuve durmiendo, me dormí hasta muy tarde también.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_59_1763236948492.ogg	\N	2025-11-15 20:02:30.239	t	registro	0.8	2025-11-15 20:02:30.239	2025-11-17 17:15:53.58
53	60	Juan, lave un poco los platos, cocine el almuerzo para Gaby y para mi y me baño.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_60_1763236964167.ogg	\N	2025-11-15 20:02:45.554	t	registro	0.8	2025-11-15 20:02:45.554	2025-11-17 17:15:56.758
36	43	Y hay que revisar si será posible cambiar el sistema de whatsapp para el actual aplicación.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_43_1762639800879.ogg	\N	2025-11-08 22:10:04.224	f	sin_clasificar	0	2025-11-08 22:10:04.224	2025-11-17 17:15:08.003
58	62	Juan, hoy de mañana revisé mis objetivos generales y ahora después te los voy a pasar.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_62_1763398931128.ogg	\N	2025-11-17 17:02:13.426	t	registro	0.8	2025-11-17 17:02:13.426	2025-11-17 17:02:16.634
121	67	Juan, después fui a buscar a Feli a la escuela.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_67_1763420217946.ogg	\N	2025-11-17 22:57:00.493	t	registro	0.8	2025-11-17 22:57:00.493	2025-11-17 22:57:02.527
35	42	pero después es también importante poder armar el sistema de whatsapps	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_42_1762639707654.ogg	\N	2025-11-08 22:08:30.319	f	sin_clasificar	0	2025-11-08 22:08:30.319	2025-11-17 17:15:06.999
39	46	Juan, hoy estuve revisando bien a fondo la postulación de Verde Urbano a Ande y estuve cambiando cosas y estuve hablando mucho con el emprendedor Álvaro y tengo como un buen caso de éxito en cuanto a presentación de proyectos al menos así quedó el emprendedor pese a que la presentación será ahora	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_46_1762804841790.ogg	\N	2025-11-10 20:00:46.384	t	registro	0.8	2025-11-10 20:00:46.384	2025-11-17 17:15:19.435
54	61	Juan, ahora fuimos, venimos a buscar a los pequeños a la casa de mi madre para ir al cumpleaños de Ximena	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_61_1763236980657.ogg	\N	2025-11-15 20:03:02.658	t	registro	0.8	2025-11-15 20:03:02.658	2025-11-17 17:16:00.168
117	63	Bueno, hoy fui con Facu al paseo en Punta Espinilla.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_63_1763420118480.ogg	\N	2025-11-17 22:55:20.979	f	sin_clasificar	0	2025-11-17 22:55:20.979	2025-11-17 22:55:20.979
118	64	Juan, hoy fui con Facu al paseo de punta a espinillo durante toda la mañana de 8 a 1.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_64_1763420145908.ogg	\N	2025-11-17 22:55:47.336	t	registro	0.8	2025-11-17 22:55:47.336	2025-11-17 22:55:51.267
119	65	Juan, después volví con Facu también y traté de trabajar haciendo, revisando la parte de la automatización del día de este chatbot	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_65_1763420166612.ogg	\N	2025-11-17 22:56:09.318	t	registro	0.8	2025-11-17 22:56:09.318	2025-11-17 22:56:11.749
120	66	Juan, mientras tanto también estaba viendo el diseño de la revista de Involucrarse Transforma.	https://377a56fa92f7e25c9951c8c32a720022.r2.cloudflarestorage.com/asistente-personal-prod/audios/2025/11/audio_66_1763420194764.ogg	\N	2025-11-17 22:56:36.569	t	registro	0.8	2025-11-17 22:56:36.569	2025-11-17 22:56:38.835
\.


--
-- Data for Name: proyectos_estrategicos; Type: TABLE DATA; Schema: public; Owner: asistente
--

COPY public.proyectos_estrategicos (id, nombre, descripcion, areas_ids, motivos_ids, destrezas_requeridas_ids, dificultades_ids, misiones_ids, justificacion_estrategica, objetivos_smart, fecha_inicio, fecha_fin_estimada, estado, prioridad_global, score_motivacional, score_alineacion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: registros; Type: TABLE DATA; Schema: public; Owner: asistente
--

COPY public.registros (id, descripcion, "duracionHoras", proyecto, "personasInvolucradas", categoria, "fechaActividad", "notaAudioId", "createdAt", "updatedAt") FROM stdin;
1	armando dos cosas a la vez, la primera es Mateos y la otra es llenado de un formulario postulación para ANDE	3	ANDE	{}	TRABAJO	2025-11-07 02:41:57.681	5	2025-11-07 02:41:57.683	2025-11-07 02:41:57.683
2	bajar a los niños y mirar videítos en el celular	1	\N	{Gaby}	PERSONAL	2025-11-07 02:42:29.691	6	2025-11-07 02:42:29.692	2025-11-07 02:42:29.692
3	respondí el mensaje que mandó Diego y estoy haciendo el formulario	\N	\N	{Diego}	TRABAJO	2025-11-07 02:42:53.831	7	2025-11-07 02:42:53.832	2025-11-07 02:42:53.832
4	hice toda la automatización y le agregué a Mateos la automatización del resumen del día	\N	\N	{Mateos}	TRABAJO	2025-11-07 04:25:59.844	8	2025-11-07 04:25:59.844	2025-11-07 04:25:59.844
5	estuve trabajando en mejorar la postulación de ANDE con CLOUD	2	ANDE	{}	TRABAJO	2025-11-07 15:41:46.85	14	2025-11-07 15:41:46.852	2025-11-07 15:41:46.852
6	tuve reunión con la energía	\N	\N	{}	TRABAJO	2025-11-07 15:42:21.405	15	2025-11-07 15:42:21.406	2025-11-07 15:42:21.406
7	tuve una reunión con Enzo y Germán de UCUBS donde me dijeron que estaban ayudando adelante del proyecto Re-Vincularse	\N	Re-Vincularse	{Enzo,Germán}	TRABAJO	2025-11-07 15:43:55.427	17	2025-11-07 15:43:55.428	2025-11-07 15:43:55.428
8	llevé a Feli a la práctica de fútbol de Mario y compré frutas y verduras en Los Patos	\N	\N	{Feli,Mario}	PERSONAL	2025-11-07 21:34:22.841	22	2025-11-07 21:34:22.842	2025-11-07 21:34:22.842
9	mandé un mail bastante complejo a Analia y Rochi para limpiar un poco la situación sobre la confirmación que estaba apurando	\N	\N	{Analia,Rochi}	TRABAJO	2025-11-07 21:35:19.356	23	2025-11-07 21:35:19.357	2025-11-07 21:35:19.357
11	revisé mis objetivos generales	2	\N	{}	PERSONAL	2025-11-17 17:02:16.617	58	2025-11-17 17:02:16.618	2025-11-17 17:02:16.618
10	gasté	\N	\N	{}	OTRO	2025-11-08 21:36:00	24	2025-11-07 21:36:27.676	2025-11-07 21:36:27.676
12	miré los avances y decidí posponer la postulación para el anda	\N	anda	{conciliador}	TRABAJO	2025-11-17 17:14:37.994	26	2025-11-17 17:14:37.995	2025-11-17 17:14:37.995
13	lavando platos y tratando de hacer el test de Involucra Hub de la base de datos	\N	Involucra Hub	{}	TRABAJO	2025-11-17 17:14:41.644	27	2025-11-17 17:14:41.645	2025-11-17 17:14:41.645
14	cociné unos fideos con huevo y tomate, hice unos pepinos al vinagre y lavé las frutas	\N	\N	{}	PERSONAL	2025-11-17 17:14:49.511	29	2025-11-17 17:14:49.512	2025-11-17 17:14:49.512
15	arreglé el puff y puse cintas en el vidrio que estaba rajado	\N	\N	{}	PERSONAL	2025-11-17 17:14:52.631	30	2025-11-17 17:14:52.632	2025-11-17 17:14:52.632
16	colgué la ropa y fui a tomar un helado con los niños y después jugamos en una placita	\N	\N	{"los niños"}	PERSONAL	2025-11-17 17:14:56.588	31	2025-11-17 17:14:56.589	2025-11-17 17:14:56.589
17	estuve en la unión de información fomento de la escuela y fui con Yanela a hablar con las personas que estaban en la obra de la placita	4	\N	{Yanela}	SOCIAL	2025-11-17 17:15:12.304	37	2025-11-17 17:15:12.305	2025-11-17 17:15:12.305
18	revisé a fondo la postulación de Verde Urbano a Ande y cambié cosas, hablé mucho con el emprendedor Álvaro	\N	Verde Urbano	{Álvaro}	TRABAJO	2025-11-17 17:15:19.43	39	2025-11-17 17:15:19.431	2025-11-17 17:15:19.431
19	estuve revisando la parte de la contabilidad de fibras	\N	fibras	{Leo,Fabián}	TRABAJO	2025-11-17 17:15:22.63	40	2025-11-17 17:15:22.631	2025-11-17 17:15:22.631
20	fui al comunal a hablar con el arquitecto, intenté contactarlo varias veces y hablé con la directora	\N	\N	{arquitecto,alcalde,directora,Álvaro}	TRABAJO	2025-11-17 17:15:39.116	46	2025-11-17 17:15:39.117	2025-11-17 17:15:39.117
21	estuve en consulta con Sara y le comenté sobre el tema de la frustración y cómo me impacta	\N	\N	{Sara}	PERSONAL	2025-11-17 17:15:43.874	49	2025-11-17 17:15:43.875	2025-11-17 17:15:43.875
22	Llevé a los niños al fútbol y estuve jugando un poco al básquetbol en la cancha nueva.	\N	\N	{Mario}	PERSONAL	2025-11-17 17:15:47.411	50	2025-11-17 17:15:47.412	2025-11-17 17:15:47.412
23	volví a casa y dormí hasta tarde	\N	\N	{}	PERSONAL	2025-11-17 17:15:50.425	51	2025-11-17 17:15:50.426	2025-11-17 17:15:50.426
24	fui a comprar el tarmo que me quedaba por comprar con el mate y estuve durmiendo	\N	\N	{}	PERSONAL	2025-11-17 17:15:53.578	52	2025-11-17 17:15:53.579	2025-11-17 17:15:53.579
25	lave un poco los platos, cocine el almuerzo para Gaby y para mi y me baño.	\N	\N	{Gaby}	PERSONAL	2025-11-17 17:15:56.756	53	2025-11-17 17:15:56.757	2025-11-17 17:15:56.757
26	fui a buscar a los pequeños a la casa de mi madre para ir al cumpleaños de Ximena	\N	\N	{Ximena}	SOCIAL	2025-11-17 17:16:00.164	54	2025-11-17 17:16:00.165	2025-11-17 17:16:00.165
27	fui con Facu al paseo de punta a espinillo	5	\N	{Facu}	PERSONAL	2025-11-17 22:55:51.256	118	2025-11-17 22:55:51.257	2025-11-17 22:55:51.257
28	traté de trabajar haciendo, revisando la parte de la automatización del día de este chatbot	\N	chatbot	{Facu}	TRABAJO	2025-11-17 22:56:11.746	119	2025-11-17 22:56:11.747	2025-11-17 22:56:11.747
29	estaba viendo el diseño de la revista de Involucrarse Transforma	\N	Involucrarse Transforma	{}	TRABAJO	2025-11-17 22:56:38.832	120	2025-11-17 22:56:38.833	2025-11-17 22:56:38.833
30	fui a buscar a Feli a la escuela	\N	\N	{Feli}	PERSONAL	2025-11-17 22:57:02.519	121	2025-11-17 22:57:02.52	2025-11-17 22:57:02.52
31	fui a Valdivia a comprar TNT para la escuela	\N	\N	{}	PERSONAL	2025-11-17 22:57:14.913	122	2025-11-17 22:57:14.914	2025-11-17 22:57:14.914
32	hice un escrito para enviar a los padres desde la Comisión Fomento	\N	Comisión Fomento	{Feli}	TRABAJO	2025-11-17 22:57:40.83	123	2025-11-17 22:57:40.833	2025-11-17 22:57:40.833
33	fui a la ortodoncista a ver cómo le estaba yendo a Feli y a cambiar mi ortodoncia	\N	\N	{Feli}	PERSONAL	2025-11-17 22:57:57.177	124	2025-11-17 22:57:57.178	2025-11-17 22:57:57.178
34	me sumé a la reunión de fe y alegría con el chatbot y pedí para poder generar un nuevo prompt	\N	\N	{}	TRABAJO	2025-11-17 22:58:17.852	125	2025-11-17 22:58:17.852	2025-11-17 22:58:17.852
35	pasé a buscar medicamentos y a comprar una garrafa	\N	\N	{}	PERSONAL	2025-11-17 22:58:46.295	126	2025-11-17 22:58:46.295	2025-11-17 22:58:46.295
36	escribí un escrito para Whatsapp para la rifa de mañana de la escuela	\N	rifa de la escuela	{}	SOCIAL	2025-11-17 22:59:05.072	127	2025-11-17 22:59:05.072	2025-11-17 22:59:05.072
37	le contesté a Valentina para poder tener una reunión el miércoles	\N	\N	{Valentina}	TRABAJO	2025-11-17 22:59:33.207	128	2025-11-17 22:59:33.207	2025-11-17 22:59:33.207
38	revisé la información del presupuesto participativo y aporté, hice un deep research para ver si realmente nos pueden o nos tienen que entregar los pliegos	\N	presupuesto participativo	{}	TRABAJO	2025-11-17 22:59:52.48	129	2025-11-17 22:59:52.48	2025-11-17 22:59:52.48
\.


--
-- Data for Name: subtareas; Type: TABLE DATA; Schema: public; Owner: asistente
--

COPY public.subtareas (id, tarea_estrategica_id, titulo, completada, tiempo_estimado_minutos, moscow, destreza_principal_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tareas; Type: TABLE DATA; Schema: public; Owner: asistente
--

COPY public.tareas (id, titulo, descripcion, "fechaVencimiento", prioridad, completada, "fechaCompletada", "notaAudioId", "createdAt", "updatedAt", proyecto_estrategico_id) FROM stdin;
1	Llamar a María	Llamar a María mañana a las 3pm para revisar el proyecto	2025-11-08 15:00:00	MEDIA	f	\N	1	2025-11-07 01:36:32.201	2025-11-07 01:36:32.201	\N
2	Armar y escribir la sección 1 del formulario de capital Semilla	Escribir y organizar la primera sección del formulario de capital Semilla de Andes.	\N	MEDIA	f	\N	2	2025-11-07 02:38:56.187	2025-11-07 02:38:56.187	\N
4	Llenar planilla de estrategias de social media	Agarrar la planilla de estrategias de social media que me mandó Metricool y tratar de llenarla como para poder empezar a generar acciones y contenido.	2025-11-07 00:00:00	MEDIA	f	\N	9	2025-11-07 04:27:26.592	2025-11-07 04:27:26.592	\N
5	Escribirle a Adri	\N	2025-11-08 00:00:00	URGENTE	f	\N	12	2025-11-07 04:55:40.01	2025-11-07 04:55:40.01	\N
6	Hacer automatización para enviar WhatsApp	Crear una automatización que envíe un mensaje de WhatsApp a la persona o a la ONG cuando se envíe o llegue un mensaje de conexión.	\N	MEDIA	f	\N	13	2025-11-07 04:57:10.941	2025-11-07 04:57:10.941	\N
7	Enviar respuestas del proyecto de Andes	Enviar las respuestas del proyecto de Andes al mail de Anaria, Rochi y Leo.	\N	MEDIA	f	\N	16	2025-11-07 15:42:53.243	2025-11-07 15:42:53.243	\N
8	Armar esquema para Ateneo	Estudiar un poco más sobre los proyectos que vienen.	\N	MEDIA	f	\N	18	2025-11-07 15:44:49.922	2025-11-07 15:44:49.922	\N
3	Escribir a Diego Sastre	Revisar si me van a apoyar desde Fibras o si no.	2025-11-08 00:00:00	MEDIA	t	\N	4	2025-11-07 02:40:29.857	2025-11-07 02:40:29.857	\N
9	Confirmar disposición de Rochi y Leo	Verificar si Rochi y Leo están dispuestos a hacer el esfuerzo para el proyecto.	\N	MEDIA	f	\N	19	2025-11-07 17:36:37.363	2025-11-07 17:36:37.363	\N
10	Copiar información a nueva base de datos	Copiar la información que tengo en las otras bases de datos y pegarlas a la nueva base de datos de involucrajado.	\N	MEDIA	f	\N	28	2025-11-17 17:14:46.792	2025-11-17 17:14:46.792	\N
11	Revisar la postulación de Álvaro	Armar algo para que queden lindas las cosas de ella.	\N	MEDIA	f	\N	32	2025-11-17 17:14:59.866	2025-11-17 17:14:59.866	\N
12	Revisar idas y vueltas y plato lleno	Revisar de vuelta lo de idas y vueltas y lo del plato lleno, junto con las cosas que tengo que hacer.	\N	MEDIA	f	\N	33	2025-11-17 17:15:03.138	2025-11-17 17:15:03.138	\N
13	Armar base de datos de POSGRES	Llenar las tablas de la base de datos para el proyecto 'Involúcrate'.	\N	MEDIA	f	\N	34	2025-11-17 17:15:05.993	2025-11-17 17:15:05.993	\N
14	Asistir a reunión del proyecto Fe y Alegría	Reunión con Diego y Pablo en Pixis.	2025-11-17 20:30:00	MEDIA	f	\N	41	2025-11-17 17:15:25.912	2025-11-17 17:15:25.912	\N
15	Enviar presentación a Analia y equipo de proyecto de impacto	Enviar la presentación que armé para la ANDE de involucrarse a Analia y las personas que están en proyecto de impacto para poder empezar a trabajar desde ahí.	\N	MEDIA	f	\N	42	2025-11-17 17:15:29.14	2025-11-17 17:15:29.14	\N
16	Contactar a Hecho sobre voluntaria	Arreglar la falta de respuesta de Hecho a la voluntaria que se contactó.	\N	MEDIA	f	\N	43	2025-11-17 17:15:31.701	2025-11-17 17:15:31.701	\N
17	Asistir a la murga	Hoy de noche tengo murga también. De ocho y media a nueve a once.	2025-11-17 23:30:00	MEDIA	f	\N	44	2025-11-17 17:15:35.067	2025-11-17 17:15:35.067	\N
\.


--
-- Data for Name: tareas_estrategicas; Type: TABLE DATA; Schema: public; Owner: asistente
--

COPY public.tareas_estrategicas (id, proyecto_id, nombre, descripcion, orden, moscow, tiempo_estimado_horas, nivel_riesgo, prioridad_velocidad_perfeccion, estado, created_at, updated_at) FROM stdin;
\.


--
-- Name: areas_vida_id_seq; Type: SEQUENCE SET; Schema: public; Owner: asistente
--

SELECT pg_catalog.setval('public.areas_vida_id_seq', 14, true);


--
-- Name: compromisos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: asistente
--

SELECT pg_catalog.setval('public.compromisos_id_seq', 3, true);


--
-- Name: destrezas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: asistente
--

SELECT pg_catalog.setval('public.destrezas_id_seq', 69, true);


--
-- Name: dificultades_id_seq; Type: SEQUENCE SET; Schema: public; Owner: asistente
--

SELECT pg_catalog.setval('public.dificultades_id_seq', 9, true);


--
-- Name: ideas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: asistente
--

SELECT pg_catalog.setval('public.ideas_id_seq', 3, true);


--
-- Name: logs_generacion_ia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: asistente
--

SELECT pg_catalog.setval('public.logs_generacion_ia_id_seq', 1, false);


--
-- Name: misiones_vida_id_seq; Type: SEQUENCE SET; Schema: public; Owner: asistente
--

SELECT pg_catalog.setval('public.misiones_vida_id_seq', 6, true);


--
-- Name: motivos_personales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: asistente
--

SELECT pg_catalog.setval('public.motivos_personales_id_seq', 12, true);


--
-- Name: notas_audio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: asistente
--

SELECT pg_catalog.setval('public.notas_audio_id_seq', 133, true);


--
-- Name: proyectos_estrategicos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: asistente
--

SELECT pg_catalog.setval('public.proyectos_estrategicos_id_seq', 1, false);


--
-- Name: registros_id_seq; Type: SEQUENCE SET; Schema: public; Owner: asistente
--

SELECT pg_catalog.setval('public.registros_id_seq', 38, true);


--
-- Name: subtareas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: asistente
--

SELECT pg_catalog.setval('public.subtareas_id_seq', 1, false);


--
-- Name: tareas_estrategicas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: asistente
--

SELECT pg_catalog.setval('public.tareas_estrategicas_id_seq', 1, false);


--
-- Name: tareas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: asistente
--

SELECT pg_catalog.setval('public.tareas_id_seq', 17, true);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: areas_vida areas_vida_nombre_key; Type: CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.areas_vida
    ADD CONSTRAINT areas_vida_nombre_key UNIQUE (nombre);


--
-- Name: areas_vida areas_vida_pkey; Type: CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.areas_vida
    ADD CONSTRAINT areas_vida_pkey PRIMARY KEY (id);


--
-- Name: compromisos compromisos_pkey; Type: CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.compromisos
    ADD CONSTRAINT compromisos_pkey PRIMARY KEY (id);


--
-- Name: destrezas destrezas_nombre_key; Type: CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.destrezas
    ADD CONSTRAINT destrezas_nombre_key UNIQUE (nombre);


--
-- Name: destrezas destrezas_pkey; Type: CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.destrezas
    ADD CONSTRAINT destrezas_pkey PRIMARY KEY (id);


--
-- Name: dificultades dificultades_nombre_key; Type: CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.dificultades
    ADD CONSTRAINT dificultades_nombre_key UNIQUE (nombre);


--
-- Name: dificultades dificultades_pkey; Type: CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.dificultades
    ADD CONSTRAINT dificultades_pkey PRIMARY KEY (id);


--
-- Name: ideas_capturadas ideas_pkey; Type: CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.ideas_capturadas
    ADD CONSTRAINT ideas_pkey PRIMARY KEY (id);


--
-- Name: logs_generacion_ia logs_generacion_ia_pkey; Type: CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.logs_generacion_ia
    ADD CONSTRAINT logs_generacion_ia_pkey PRIMARY KEY (id);


--
-- Name: misiones_vida misiones_vida_nombre_key; Type: CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.misiones_vida
    ADD CONSTRAINT misiones_vida_nombre_key UNIQUE (nombre);


--
-- Name: misiones_vida misiones_vida_pkey; Type: CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.misiones_vida
    ADD CONSTRAINT misiones_vida_pkey PRIMARY KEY (id);


--
-- Name: motivos_personales motivos_personales_nombre_key; Type: CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.motivos_personales
    ADD CONSTRAINT motivos_personales_nombre_key UNIQUE (nombre);


--
-- Name: motivos_personales motivos_personales_pkey; Type: CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.motivos_personales
    ADD CONSTRAINT motivos_personales_pkey PRIMARY KEY (id);


--
-- Name: notas_audio notas_audio_pkey; Type: CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.notas_audio
    ADD CONSTRAINT notas_audio_pkey PRIMARY KEY (id);


--
-- Name: proyectos_estrategicos proyectos_estrategicos_pkey; Type: CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.proyectos_estrategicos
    ADD CONSTRAINT proyectos_estrategicos_pkey PRIMARY KEY (id);


--
-- Name: registros registros_pkey; Type: CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.registros
    ADD CONSTRAINT registros_pkey PRIMARY KEY (id);


--
-- Name: subtareas subtareas_pkey; Type: CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.subtareas
    ADD CONSTRAINT subtareas_pkey PRIMARY KEY (id);


--
-- Name: tareas_estrategicas tareas_estrategicas_pkey; Type: CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.tareas_estrategicas
    ADD CONSTRAINT tareas_estrategicas_pkey PRIMARY KEY (id);


--
-- Name: tareas tareas_pkey; Type: CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.tareas
    ADD CONSTRAINT tareas_pkey PRIMARY KEY (id);


--
-- Name: compromisos_cumplido_idx; Type: INDEX; Schema: public; Owner: asistente
--

CREATE INDEX compromisos_cumplido_idx ON public.compromisos USING btree (cumplido);


--
-- Name: compromisos_fechaLimite_idx; Type: INDEX; Schema: public; Owner: asistente
--

CREATE INDEX "compromisos_fechaLimite_idx" ON public.compromisos USING btree ("fechaLimite");


--
-- Name: compromisos_notaAudioId_idx; Type: INDEX; Schema: public; Owner: asistente
--

CREATE INDEX "compromisos_notaAudioId_idx" ON public.compromisos USING btree ("notaAudioId");


--
-- Name: compromisos_personaNombre_idx; Type: INDEX; Schema: public; Owner: asistente
--

CREATE INDEX "compromisos_personaNombre_idx" ON public.compromisos USING btree ("personaNombre");


--
-- Name: ideas_capturadas_categoria_idx; Type: INDEX; Schema: public; Owner: asistente
--

CREATE INDEX ideas_capturadas_categoria_idx ON public.ideas_capturadas USING btree (categoria);


--
-- Name: ideas_capturadas_implementada_idx; Type: INDEX; Schema: public; Owner: asistente
--

CREATE INDEX ideas_capturadas_implementada_idx ON public.ideas_capturadas USING btree (implementada);


--
-- Name: ideas_categoria_idx; Type: INDEX; Schema: public; Owner: asistente
--

CREATE INDEX ideas_categoria_idx ON public.ideas_capturadas USING btree (categoria);


--
-- Name: ideas_implementada_idx; Type: INDEX; Schema: public; Owner: asistente
--

CREATE INDEX ideas_implementada_idx ON public.ideas_capturadas USING btree (implementada);


--
-- Name: ideas_notaAudioId_idx; Type: INDEX; Schema: public; Owner: asistente
--

CREATE INDEX "ideas_notaAudioId_idx" ON public.ideas_capturadas USING btree ("notaAudioId");


--
-- Name: notas_audio_fechaGrabacion_idx; Type: INDEX; Schema: public; Owner: asistente
--

CREATE INDEX "notas_audio_fechaGrabacion_idx" ON public.notas_audio USING btree ("fechaGrabacion");


--
-- Name: notas_audio_procesado_idx; Type: INDEX; Schema: public; Owner: asistente
--

CREATE INDEX notas_audio_procesado_idx ON public.notas_audio USING btree (procesado);


--
-- Name: notas_audio_tipoDetectado_idx; Type: INDEX; Schema: public; Owner: asistente
--

CREATE INDEX "notas_audio_tipoDetectado_idx" ON public.notas_audio USING btree ("tipoDetectado");


--
-- Name: notas_audio_transcripcionId_idx; Type: INDEX; Schema: public; Owner: asistente
--

CREATE INDEX "notas_audio_transcripcionId_idx" ON public.notas_audio USING btree ("transcripcionId");


--
-- Name: notas_audio_transcripcionId_key; Type: INDEX; Schema: public; Owner: asistente
--

CREATE UNIQUE INDEX "notas_audio_transcripcionId_key" ON public.notas_audio USING btree ("transcripcionId");


--
-- Name: registros_categoria_idx; Type: INDEX; Schema: public; Owner: asistente
--

CREATE INDEX registros_categoria_idx ON public.registros USING btree (categoria);


--
-- Name: registros_fechaActividad_idx; Type: INDEX; Schema: public; Owner: asistente
--

CREATE INDEX "registros_fechaActividad_idx" ON public.registros USING btree ("fechaActividad");


--
-- Name: registros_notaAudioId_idx; Type: INDEX; Schema: public; Owner: asistente
--

CREATE INDEX "registros_notaAudioId_idx" ON public.registros USING btree ("notaAudioId");


--
-- Name: registros_proyecto_idx; Type: INDEX; Schema: public; Owner: asistente
--

CREATE INDEX registros_proyecto_idx ON public.registros USING btree (proyecto);


--
-- Name: tareas_completada_idx; Type: INDEX; Schema: public; Owner: asistente
--

CREATE INDEX tareas_completada_idx ON public.tareas USING btree (completada);


--
-- Name: tareas_fechaVencimiento_idx; Type: INDEX; Schema: public; Owner: asistente
--

CREATE INDEX "tareas_fechaVencimiento_idx" ON public.tareas USING btree ("fechaVencimiento");


--
-- Name: tareas_notaAudioId_idx; Type: INDEX; Schema: public; Owner: asistente
--

CREATE INDEX "tareas_notaAudioId_idx" ON public.tareas USING btree ("notaAudioId");


--
-- Name: tareas_prioridad_idx; Type: INDEX; Schema: public; Owner: asistente
--

CREATE INDEX tareas_prioridad_idx ON public.tareas USING btree (prioridad);


--
-- Name: compromisos compromisos_notaAudioId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.compromisos
    ADD CONSTRAINT "compromisos_notaAudioId_fkey" FOREIGN KEY ("notaAudioId") REFERENCES public.notas_audio(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ideas_capturadas ideas_capturadas_proyecto_estrategico_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.ideas_capturadas
    ADD CONSTRAINT ideas_capturadas_proyecto_estrategico_id_fkey FOREIGN KEY (proyecto_estrategico_id) REFERENCES public.proyectos_estrategicos(id) ON DELETE SET NULL;


--
-- Name: ideas_capturadas ideas_notaAudioId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.ideas_capturadas
    ADD CONSTRAINT "ideas_notaAudioId_fkey" FOREIGN KEY ("notaAudioId") REFERENCES public.notas_audio(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: logs_generacion_ia logs_generacion_ia_proyecto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.logs_generacion_ia
    ADD CONSTRAINT logs_generacion_ia_proyecto_id_fkey FOREIGN KEY (proyecto_id) REFERENCES public.proyectos_estrategicos(id) ON DELETE SET NULL;


--
-- Name: registros registros_notaAudioId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.registros
    ADD CONSTRAINT "registros_notaAudioId_fkey" FOREIGN KEY ("notaAudioId") REFERENCES public.notas_audio(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subtareas subtareas_destreza_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.subtareas
    ADD CONSTRAINT subtareas_destreza_principal_id_fkey FOREIGN KEY (destreza_principal_id) REFERENCES public.destrezas(id) ON DELETE SET NULL;


--
-- Name: subtareas subtareas_tarea_estrategica_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.subtareas
    ADD CONSTRAINT subtareas_tarea_estrategica_id_fkey FOREIGN KEY (tarea_estrategica_id) REFERENCES public.tareas_estrategicas(id) ON DELETE RESTRICT;


--
-- Name: tareas_estrategicas tareas_estrategicas_proyecto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.tareas_estrategicas
    ADD CONSTRAINT tareas_estrategicas_proyecto_id_fkey FOREIGN KEY (proyecto_id) REFERENCES public.proyectos_estrategicos(id) ON DELETE RESTRICT;


--
-- Name: tareas tareas_notaAudioId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.tareas
    ADD CONSTRAINT "tareas_notaAudioId_fkey" FOREIGN KEY ("notaAudioId") REFERENCES public.notas_audio(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tareas tareas_proyecto_estrategico_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: asistente
--

ALTER TABLE ONLY public.tareas
    ADD CONSTRAINT tareas_proyecto_estrategico_id_fkey FOREIGN KEY (proyecto_estrategico_id) REFERENCES public.proyectos_estrategicos(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

